import { j as jsxRuntimeExports } from "../ssr.js";
import "util";
import "stream";
import "path";
import "http";
import "https";
import "url";
import "fs";
import "assert";
import "tty";
import "os";
import "zlib";
import "events";
import "process";
const Index = ({ listings }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: "Index" });
};
export {
  Index as default
};
